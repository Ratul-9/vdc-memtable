# VDC memtable benchmark report

## System

| Item | Value |
|---|---|
| Date | 2026-11-22 08:21:00 |
| Kernel | Linux 7.0.0-1020-azure |
| Machine | x86_64 |
| CPU | INTEL(R) XEON(R) PLATINUM 8573C |
| Online CPUs | 4 |
| Base page size | 4096 B |
| Cache line size | 64 B |
| L1 Data cache | 48 KiB, 12-way, 64 sets, 64 B lines |
| L2 Unified cache | 2048 KiB, 16-way, 2048 sets, 64 B lines |
| L3 Unified cache | 266240 KiB, 20-way, 212992 sets, 64 B lines |
| Transparent huge pages | always [madvise] never (base mode opts out per mapping) |
| HugePages total / free | 128 / 128 (size 2048 kB) |
| perf_event_paranoid | 1 |
| Compiler | 13.3.0 |

## Configuration

| Setting | Value |
|---|---|
| Variants | vdc j=6, vdc j=11, vdc j=20, hash, skiplist |
| Key counts | 1K, 10K, 100K, 500K, 1M (K = 1,000, M = 1,000,000; key domain 0 .. 2^20-1) |
| Patterns | seq, dense_rand, rand |
| Operations | insert, get_hit, get_miss, update, delete |
| Page modes | base, hugetlb |
| Repetitions | 5 per counter set, 1 counter set(s); values are medians |
| Min ops per read/update sample | 1000000 |
| Value size | 32 B (inline in the Node) |
| Memory | fully committed before measuring (populate) |
| Cache flush between repetitions | 0 MiB |
| Seed | 42 |
| Hardware counters | page faults |

Patterns: **seq** = keys 0..N-1 in ascending order; **dense_rand** = keys 0..N-1 in random order; **rand** = N random keys from the whole domain in random order.
Operations: **insert** = N new keys into an empty table; **get_hit** / **get_miss** = lookups of present / never-written keys; **get_batch** = get_hit through the prefetching batch API; **update** = overwrite present keys; **delete** = tombstone present keys.

## Checks

| Check | Target | Result | Worst value | Where |
|---|---|---|---|---|
| Correctness: every operation returned the expected status | all ok | ✅ PASS | - | - |
| O(1): instructions/op flat across key counts (vdc) | max/min ≤ 1.10 | n/a | needs counters and ≥ 2 key counts | - |
| O(1): instructions/op flat across key counts (hash) | max/min ≤ 1.10 | n/a | needs counters and ≥ 2 key counts | - |
| O(1): instructions/op flat across key counts (skiplist) | max/min ≤ 1.10 | n/a | needs counters and ≥ 2 key counts | - |
| Cache: LLC misses/op for vdc | ≤ 1.25 | n/a | needs counters | - |
| TLB: dTLB misses/op for vdc on hugetlb pages | ≤ 0.05 | n/a | needs hugetlb run and counters | - |
| Page faults during measured runs (median) | 0 | ✅ PASS | 0 | - |

Time per operation is expected to grow with the key count (the working set moves from L1 to DRAM); instructions per operation must not. LLC misses can exceed 1.0 when the hardware adjacent-line prefetcher fetches the neighbouring line (accepted cost, P17).

## O(1) detail: max/min instructions per op across key counts

1.00 = identical work at every key count. ✅ ≤ 1.10.

**base pages, seq**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**base pages, dense_rand**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**base pages, rand**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**hugetlb pages, seq**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**hugetlb pages, dense_rand**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**hugetlb pages, rand**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

## Huge pages vs base pages (1M keys)

Cell = base → hugetlb.

**seq: dTLB misses per operation (load + store)**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**seq: Time per operation (ns/op)**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | 9.0 → 8.3 (-8%) | 8.2 → 8.1 (-0%) | 6.3 → 6.6 (+6%) | 27.3 → 23.6 (-14%) | 104.8 → 104.4 (-0%) |
| get_hit | 5.8 → 5.2 (-11%) | 4.9 → 5.0 (+1%) | 3.3 → 3.3 (-0%) | 23.7 → 19.3 (-19%) | 109.4 → 108.3 (-1%) |
| get_miss | 4.6 → 4.5 (-3%) | 4.3 → 4.3 (-0%) | 2.8 → 2.8 (-2%) | 38.5 → 31.9 (-17%) | 22.3 → 22.0 (-1%) |
| update | 9.1 → 8.7 (-4%) | 8.4 → 8.4 (+0%) | 6.7 → 6.9 (+4%) | 32.9 → 29.5 (-10%) | 103.5 → 102.0 (-2%) |
| delete | 5.8 → 5.2 (-11%) | 5.0 → 4.9 (-1%) | 3.4 → 3.3 (-3%) | 23.1 → 19.6 (-15%) | 105.3 → 104.4 (-1%) |

**dense_rand: dTLB misses per operation (load + store)**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**dense_rand: Time per operation (ns/op)**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | 16.2 → 12.6 (-22%) | 17.2 → 12.8 (-26%) | 13.2 → 9.6 (-27%) | 27.2 → 23.1 (-15%) | 817.2 → 577.2 (-29%) |
| get_hit | 12.3 → 9.9 (-20%) | 12.6 → 10.0 (-21%) | 8.4 → 6.0 (-29%) | 22.3 → 19.1 (-14%) | 1131.0 → 744.2 (-34%) |
| get_miss | 9.1 → 8.7 (-4%) | 9.5 → 8.9 (-6%) | 5.5 → 5.0 (-9%) | 38.2 → 32.0 (-16%) | 34.1 → 33.8 (-1%) |
| update | 17.6 → 14.5 (-18%) | 19.5 → 14.2 (-27%) | 15.1 → 9.9 (-34%) | 31.4 → 28.3 (-10%) | 1273.1 → 837.7 (-34%) |
| delete | 12.9 → 10.5 (-18%) | 14.8 → 10.2 (-31%) | 9.4 → 5.8 (-38%) | 22.3 → 19.7 (-11%) | 1218.6 → 803.1 (-34%) |

**rand: dTLB misses per operation (load + store)**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**rand: Time per operation (ns/op)**

| op | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| insert | 16.5 → 13.0 (-21%) | 18.1 → 12.6 (-30%) | 14.1 → 9.6 (-32%) | 28.9 → 22.8 (-21%) | 826.6 → 570.2 (-31%) |
| get_hit | 13.1 → 10.5 (-20%) | 13.3 → 9.9 (-26%) | 8.6 → 6.0 (-31%) | 22.7 → 18.6 (-18%) | 1124.0 → 734.5 (-35%) |
| get_miss | 10.8 → 8.9 (-18%) | 10.9 → 8.6 (-21%) | 6.5 → 4.9 (-25%) | 39.4 → 32.0 (-19%) | 1006.5 → 638.5 (-37%) |
| update | 20.2 → 15.0 (-26%) | 23.3 → 14.0 (-40%) | 15.5 → 9.9 (-36%) | 33.2 → 27.1 (-18%) | 1269.4 → 814.6 (-36%) |
| delete | 15.1 → 11.0 (-27%) | 18.1 → 10.2 (-43%) | 10.1 → 5.7 (-43%) | 23.6 → 19.2 (-19%) | 1244.3 → 783.3 (-37%) |

## Fastest variant per workload (1M keys, ns/op)

**base pages**

| op | seq | dense_rand | rand |
|---|---|---|---|
| insert | vdc j=20 (6.3) | vdc j=20 (13.2) | vdc j=20 (14.1) |
| get_hit | vdc j=20 (3.3) | vdc j=20 (8.4) | vdc j=20 (8.6) |
| get_miss | vdc j=20 (2.8) | vdc j=20 (5.5) | vdc j=20 (6.5) |
| update | vdc j=20 (6.7) | vdc j=20 (15.1) | vdc j=20 (15.5) |
| delete | vdc j=20 (3.4) | vdc j=20 (9.4) | vdc j=20 (10.1) |

**hugetlb pages**

| op | seq | dense_rand | rand |
|---|---|---|---|
| insert | vdc j=20 (6.6) | vdc j=20 (9.6) | vdc j=20 (9.6) |
| get_hit | vdc j=20 (3.3) | vdc j=20 (6.0) | vdc j=20 (6.0) |
| get_miss | vdc j=20 (2.8) | vdc j=20 (5.0) | vdc j=20 (4.9) |
| update | vdc j=20 (6.9) | vdc j=20 (9.9) | vdc j=20 (9.9) |
| delete | vdc j=20 (3.3) | vdc j=20 (5.8) | vdc j=20 (5.7) |

## Results by workload

Rows = key count, columns = variant. All values are per operation (medians). The CSV file has every metric, including cycles and page faults.

### base pages / seq / insert

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 11.2 | 10.0 | 9.2 | 31.2 | 70.4 |
| 10K | 10.0 | 8.6 | 7.3 | 16.6 | 79.9 |
| 100K | 9.6 | 8.2 | 6.8 | 12.0 | 97.6 |
| 500K | 9.1 | 8.2 | 6.2 | 16.5 | 108.4 |
| 1M | 9.0 | 8.2 | 6.3 | 27.3 | 104.8 |

### base pages / seq / get_hit

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 4.7 | 4.7 | 3.1 | 4.5 | 49.1 |
| 10K | 5.0 | 4.7 | 2.9 | 7.0 | 76.9 |
| 100K | 5.8 | 4.9 | 3.3 | 10.5 | 100.8 |
| 500K | 5.9 | 4.9 | 3.3 | 13.7 | 110.5 |
| 1M | 5.8 | 4.9 | 3.3 | 23.7 | 109.4 |

### base pages / seq / get_miss

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 4.0 | 4.0 | 2.2 | 3.4 | 17.9 |
| 10K | 4.3 | 4.0 | 2.2 | 5.5 | 25.8 |
| 100K | 5.1 | 4.3 | 2.8 | 9.9 | 31.4 |
| 500K | 5.5 | 5.8 | 3.4 | 20.6 | 44.3 |
| 1M | 4.6 | 4.3 | 2.8 | 38.5 | 22.3 |

### base pages / seq / update

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 9.0 | 8.3 | 6.4 | 6.5 | 49.4 |
| 10K | 9.2 | 8.2 | 6.4 | 8.4 | 74.6 |
| 100K | 9.6 | 8.4 | 6.5 | 11.8 | 96.1 |
| 500K | 9.3 | 8.5 | 6.5 | 17.4 | 105.3 |
| 1M | 9.1 | 8.4 | 6.7 | 32.9 | 103.5 |

### base pages / seq / delete

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.4 | 4.8 | 3.0 | 4.2 | 57.5 |
| 10K | 5.6 | 4.5 | 2.9 | 6.9 | 75.8 |
| 100K | 6.1 | 4.9 | 3.4 | 9.0 | 93.3 |
| 500K | 5.9 | 4.9 | 3.3 | 12.5 | 105.8 |
| 1M | 5.8 | 5.0 | 3.4 | 23.1 | 105.3 |

### base pages / dense_rand / insert

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 13.0 | 11.5 | 9.1 | 17.0 | 93.9 |
| 10K | 13.6 | 13.2 | 9.7 | 13.8 | 155.9 |
| 100K | 13.6 | 13.1 | 10.0 | 12.1 | 296.3 |
| 500K | 15.9 | 15.8 | 12.4 | 16.5 | 599.2 |
| 1M | 16.2 | 17.2 | 13.2 | 27.2 | 817.2 |

### base pages / dense_rand / get_hit

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.4 | 5.0 | 3.0 | 4.4 | 68.1 |
| 10K | 8.8 | 5.4 | 3.0 | 7.0 | 166.2 |
| 100K | 10.1 | 10.1 | 6.1 | 10.7 | 363.9 |
| 500K | 12.0 | 12.1 | 7.5 | 13.8 | 817.7 |
| 1M | 12.3 | 12.6 | 8.4 | 22.3 | 1131.0 |

### base pages / dense_rand / get_miss

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 4.6 | 4.5 | 2.5 | 3.6 | 15.9 |
| 10K | 6.1 | 6.1 | 3.7 | 5.6 | 18.7 |
| 100K | 10.7 | 10.7 | 6.3 | 9.9 | 18.8 |
| 500K | 16.5 | 20.1 | 9.6 | 20.9 | 49.8 |
| 1M | 9.1 | 9.5 | 5.5 | 38.2 | 34.1 |

### base pages / dense_rand / update

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 9.6 | 8.7 | 6.2 | 6.4 | 60.0 |
| 10K | 12.4 | 8.4 | 6.5 | 8.3 | 165.9 |
| 100K | 13.8 | 13.5 | 10.2 | 11.9 | 398.0 |
| 500K | 18.1 | 18.6 | 13.2 | 17.6 | 895.7 |
| 1M | 17.6 | 19.5 | 15.1 | 31.4 | 1273.1 |

### base pages / dense_rand / delete

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.8 | 4.9 | 2.9 | 4.5 | 80.0 |
| 10K | 8.7 | 5.1 | 3.4 | 6.9 | 170.4 |
| 100K | 9.8 | 9.7 | 5.9 | 9.0 | 377.5 |
| 500K | 11.8 | 11.7 | 7.4 | 12.7 | 874.8 |
| 1M | 12.9 | 14.8 | 9.4 | 22.3 | 1218.6 |

### base pages / rand / insert

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 22.9 | 23.1 | 17.9 | 18.2 | 95.2 |
| 10K | 24.4 | 19.2 | 15.1 | 17.2 | 152.5 |
| 100K | 16.3 | 16.1 | 12.6 | 12.0 | 302.2 |
| 500K | 16.3 | 16.1 | 12.7 | 16.5 | 604.4 |
| 1M | 16.5 | 18.1 | 14.1 | 28.9 | 826.6 |

### base pages / rand / get_hit

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.9 | 5.8 | 3.5 | 4.4 | 69.7 |
| 10K | 7.3 | 7.3 | 4.7 | 7.0 | 163.0 |
| 100K | 12.1 | 12.1 | 7.6 | 10.6 | 384.5 |
| 500K | 12.2 | 12.3 | 7.6 | 13.7 | 750.4 |
| 1M | 13.1 | 13.3 | 8.6 | 22.7 | 1124.0 |

### base pages / rand / get_miss

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 4.6 | 4.5 | 2.4 | 3.4 | 57.9 |
| 10K | 6.1 | 6.1 | 3.7 | 5.6 | 158.2 |
| 100K | 10.8 | 10.7 | 6.3 | 9.9 | 376.4 |
| 500K | 20.3 | 16.0 | 9.0 | 20.9 | 748.4 |
| 1M | 10.8 | 10.9 | 6.5 | 39.4 | 1006.5 |

### base pages / rand / update

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 9.3 | 8.6 | 6.8 | 6.6 | 59.2 |
| 10K | 11.0 | 11.0 | 8.6 | 8.4 | 163.5 |
| 100K | 16.1 | 16.2 | 12.7 | 11.9 | 399.9 |
| 500K | 24.5 | 18.5 | 13.7 | 17.9 | 875.1 |
| 1M | 20.2 | 23.3 | 15.5 | 33.2 | 1269.4 |

### base pages / rand / delete

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 6.1 | 5.6 | 4.3 | 4.6 | 82.6 |
| 10K | 7.6 | 7.6 | 5.9 | 6.9 | 167.0 |
| 100K | 11.5 | 11.6 | 7.5 | 9.0 | 388.6 |
| 500K | 13.6 | 11.8 | 7.6 | 12.8 | 839.2 |
| 1M | 15.1 | 18.1 | 10.1 | 23.6 | 1244.3 |

### hugetlb pages / seq / insert

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 8.8 | 8.5 | 8.4 | 10.6 | 70.7 |
| 10K | 8.4 | 8.2 | 8.0 | 9.2 | 84.2 |
| 100K | 8.2 | 8.1 | 6.6 | 8.9 | 98.7 |
| 500K | 8.1 | 8.1 | 6.5 | 13.3 | 107.6 |
| 1M | 8.3 | 8.1 | 6.6 | 23.6 | 104.4 |

### hugetlb pages / seq / get_hit

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 4.7 | 4.7 | 3.1 | 4.0 | 49.2 |
| 10K | 5.2 | 4.7 | 2.9 | 4.5 | 77.0 |
| 100K | 5.2 | 4.8 | 3.3 | 7.9 | 101.0 |
| 500K | 5.2 | 4.8 | 3.3 | 10.7 | 108.9 |
| 1M | 5.2 | 5.0 | 3.3 | 19.3 | 108.3 |

### hugetlb pages / seq / get_miss

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.7 | 4.0 | 2.2 | 3.3 | 18.3 |
| 10K | 4.5 | 4.0 | 2.2 | 3.5 | 25.3 |
| 100K | 4.5 | 4.2 | 2.7 | 7.9 | 31.5 |
| 500K | 4.8 | 5.0 | 2.9 | 17.6 | 44.5 |
| 1M | 4.5 | 4.3 | 2.8 | 31.9 | 22.0 |

### hugetlb pages / seq / update

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 8.1 | 8.3 | 6.4 | 6.4 | 49.3 |
| 10K | 8.4 | 8.3 | 6.5 | 6.3 | 74.7 |
| 100K | 8.4 | 8.4 | 6.5 | 8.8 | 96.4 |
| 500K | 8.4 | 8.4 | 6.6 | 14.1 | 103.6 |
| 1M | 8.7 | 8.4 | 6.9 | 29.5 | 102.0 |

### hugetlb pages / seq / delete

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.1 | 4.8 | 3.1 | 3.8 | 55.9 |
| 10K | 4.9 | 4.6 | 2.9 | 3.6 | 76.0 |
| 100K | 4.9 | 4.7 | 3.3 | 6.5 | 93.1 |
| 500K | 5.0 | 4.8 | 3.3 | 9.8 | 104.1 |
| 1M | 5.2 | 4.9 | 3.3 | 19.6 | 104.4 |

### hugetlb pages / dense_rand / insert

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 11.8 | 11.3 | 9.2 | 9.0 | 95.0 |
| 10K | 12.2 | 12.3 | 9.4 | 8.3 | 149.2 |
| 100K | 12.3 | 12.4 | 9.3 | 8.9 | 252.4 |
| 500K | 12.4 | 12.5 | 9.5 | 13.1 | 447.3 |
| 1M | 12.6 | 12.8 | 9.6 | 23.1 | 577.2 |

### hugetlb pages / dense_rand / get_hit

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.1 | 5.0 | 3.1 | 4.0 | 68.7 |
| 10K | 9.6 | 5.0 | 3.0 | 4.5 | 151.4 |
| 100K | 9.6 | 9.6 | 5.8 | 8.0 | 312.3 |
| 500K | 9.7 | 9.7 | 5.9 | 10.8 | 556.1 |
| 1M | 9.9 | 10.0 | 6.0 | 19.1 | 744.2 |

### hugetlb pages / dense_rand / get_miss

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 4.0 | 4.0 | 2.2 | 3.3 | 16.3 |
| 10K | 4.1 | 4.1 | 2.3 | 3.5 | 18.8 |
| 100K | 8.6 | 8.6 | 4.9 | 7.8 | 19.4 |
| 500K | 12.9 | 13.2 | 6.1 | 17.1 | 37.7 |
| 1M | 8.7 | 8.9 | 5.0 | 32.0 | 33.8 |

### hugetlb pages / dense_rand / update

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 8.3 | 8.9 | 6.6 | 6.4 | 60.5 |
| 10K | 12.7 | 8.8 | 6.6 | 6.3 | 149.3 |
| 100K | 12.7 | 12.9 | 9.6 | 8.9 | 334.2 |
| 500K | 14.1 | 13.7 | 9.8 | 14.0 | 596.6 |
| 1M | 14.5 | 14.2 | 9.9 | 28.3 | 837.7 |

### hugetlb pages / dense_rand / delete

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.6 | 4.8 | 3.0 | 4.5 | 80.4 |
| 10K | 8.9 | 4.7 | 2.9 | 3.7 | 153.5 |
| 100K | 9.0 | 9.1 | 5.4 | 6.5 | 319.4 |
| 500K | 9.3 | 9.3 | 5.5 | 9.9 | 566.0 |
| 1M | 10.5 | 10.2 | 5.8 | 19.7 | 803.1 |

### hugetlb pages / rand / insert

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 13.5 | 12.8 | 9.7 | 9.2 | 96.6 |
| 10K | 15.0 | 12.5 | 9.9 | 13.9 | 149.8 |
| 100K | 12.4 | 12.4 | 9.5 | 8.9 | 253.9 |
| 500K | 12.5 | 12.5 | 9.5 | 13.2 | 449.1 |
| 1M | 13.0 | 12.6 | 9.6 | 22.8 | 570.2 |

### hugetlb pages / rand / get_hit

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 5.1 | 5.1 | 3.0 | 4.1 | 70.0 |
| 10K | 5.1 | 5.1 | 2.9 | 4.4 | 148.7 |
| 100K | 9.7 | 9.6 | 5.8 | 7.9 | 323.1 |
| 500K | 9.7 | 9.7 | 5.9 | 10.8 | 526.1 |
| 1M | 10.5 | 9.9 | 6.0 | 18.6 | 734.5 |

### hugetlb pages / rand / get_miss

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 4.0 | 4.0 | 2.2 | 3.3 | 57.5 |
| 10K | 4.1 | 4.1 | 2.2 | 3.5 | 144.4 |
| 100K | 8.6 | 8.7 | 4.9 | 7.8 | 317.1 |
| 500K | 14.3 | 15.4 | 5.5 | 17.9 | 524.0 |
| 1M | 8.9 | 8.6 | 4.9 | 32.0 | 638.5 |

### hugetlb pages / rand / update

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 8.5 | 8.3 | 6.2 | 6.2 | 59.7 |
| 10K | 8.4 | 8.4 | 6.2 | 6.3 | 147.5 |
| 100K | 12.9 | 12.9 | 9.6 | 8.9 | 335.0 |
| 500K | 14.0 | 14.4 | 9.7 | 14.6 | 592.8 |
| 1M | 15.0 | 14.0 | 9.9 | 27.1 | 814.6 |

### hugetlb pages / rand / delete

Time per operation (ns/op)

| keys | vdc j=6 | vdc j=11 | vdc j=20 | hash | skiplist |
|---|---:|---:|---:|---:|---:|
| 1K | 4.8 | 4.8 | 3.0 | 4.1 | 82.6 |
| 10K | 4.8 | 4.7 | 3.0 | 3.7 | 151.3 |
| 100K | 9.1 | 9.2 | 5.4 | 6.5 | 328.7 |
| 500K | 9.3 | 9.4 | 5.5 | 10.0 | 573.2 |
| 1M | 11.0 | 10.2 | 5.7 | 19.2 | 783.3 |
