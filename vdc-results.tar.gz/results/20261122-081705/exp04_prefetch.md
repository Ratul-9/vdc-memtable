# Experiment 04: prefetch distance for batched gets

1000000 keys, j = 6, median of 7 runs. Cell = ns/op (speedup vs no prefetch).

| prefetch distance | base / dense_rand | base / rand | hugetlb / dense_rand | hugetlb / rand |
|---|---:|---:|---:|---:|
| 0 (no prefetch) | 16.4 (1.00x) | 12.2 (1.00x) | 13.7 (1.00x) | 9.4 (1.00x) |
| 1 | 14.5 (1.13x) | 15.2 (0.80x) | 11.0 (1.24x) | 11.1 (0.85x) |
| 2 | 12.1 (1.36x) | 12.4 (0.98x) | 9.5 (1.44x) | 9.5 (0.99x) |
| 4 | 9.7 (1.70x) | 10.5 (1.16x) | 7.6 (1.79x) | 7.6 (1.23x) |
| 8 | 9.4 (1.74x) | 9.6 (1.27x) | 7.2 (1.91x) | 7.1 (1.32x) |
| 16 | 9.3 (1.77x) | 9.3 (1.31x) | 7.0 (1.94x) | 7.1 (1.33x) |
| 32 | 9.3 (1.76x) | 9.4 (1.30x) | 7.1 (1.93x) | 7.1 (1.33x) |
| 64 | 9.5 (1.73x) | 9.5 (1.28x) | 7.1 (1.93x) | 7.1 (1.33x) |
| memtable_get_batch (16) | 9.4 (1.74x) | 9.5 (1.29x) | 7.8 (1.75x) | 7.8 (1.20x) |
