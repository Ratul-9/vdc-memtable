# VDC memtable benchmark report

## System

| Item | Value |
|---|---|
| Date | 2026-11-22 08:17:41 |
| Kernel | Linux 7.0.0-1020-azure |
| Machine | x86_64 |
| CPU | INTEL(R) XEON(R) PLATINUM 8573C |
| Online CPUs | 4 |
| Base page size | 4096 B |
| Cache line size | 64 B |
| L1 Data cache | 48 KiB, 12-way, 64 sets, 64 B lines |
| L2 Unified cache | 2048 KiB, 16-way, 2048 sets, 64 B lines |
| L3 Unified cache | 266240 KiB, 20-way, 212992 sets, 64 B lines |
| Transparent huge pages | always [madvise] never (base mode opts out per mapping) |
| HugePages total / free | 128 / 128 (size 2048 kB) |
| perf_event_paranoid | 1 |
| Compiler | 13.3.0 |

## Configuration

| Setting | Value |
|---|---|
| Variants | j=6, j=8, j=11, j=15, j=20 |
| Key counts | 1K, 10K, 100K, 500K, 1M (K = 1,000, M = 1,000,000; key domain 0 .. 2^20-1) |
| Patterns | seq, dense_rand, rand |
| Operations | insert, get_hit, get_miss, get_batch, update, delete |
| Page modes | base, hugetlb |
| Repetitions | 5 per counter set, 1 counter set(s); values are medians |
| Min ops per read/update sample | 1000000 |
| Value size | 32 B (inline in the Node) |
| Memory | fully committed before measuring (populate) |
| Cache flush between repetitions | 0 MiB |
| Seed | 42 |
| Hardware counters | page faults |

Patterns: **seq** = keys 0..N-1 in ascending order; **dense_rand** = keys 0..N-1 in random order; **rand** = N random keys from the whole domain in random order.
Operations: **insert** = N new keys into an empty table; **get_hit** / **get_miss** = lookups of present / never-written keys; **get_batch** = get_hit through the prefetching batch API; **update** = overwrite present keys; **delete** = tombstone present keys.

## Checks

| Check | Target | Result | Worst value | Where |
|---|---|---|---|---|
| Correctness: every operation returned the expected status | all ok | ✅ PASS | - | - |
| O(1): instructions/op flat across key counts (vdc) | max/min ≤ 1.10 | n/a | needs counters and ≥ 2 key counts | - |
| Cache: LLC misses/op for vdc | ≤ 1.25 | n/a | needs counters | - |
| TLB: dTLB misses/op for vdc on hugetlb pages | ≤ 0.05 | n/a | needs hugetlb run and counters | - |
| Page faults during measured runs (median) | 0 | ✅ PASS | 0 | - |

Time per operation is expected to grow with the key count (the working set moves from L1 to DRAM); instructions per operation must not. LLC misses can exceed 1.0 when the hardware adjacent-line prefetcher fetches the neighbouring line (accepted cost, P17).

## O(1) detail: max/min instructions per op across key counts

1.00 = identical work at every key count. ✅ ≤ 1.10.

**base pages, seq**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**base pages, dense_rand**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**base pages, rand**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**hugetlb pages, seq**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**hugetlb pages, dense_rand**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**hugetlb pages, rand**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

## Huge pages vs base pages (1M keys)

Cell = base → hugetlb.

**seq: dTLB misses per operation (load + store)**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**seq: Time per operation (ns/op)**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | 9.0 → 8.3 (-8%) | 8.3 → 8.1 (-3%) | 8.2 → 8.1 (-1%) | 8.1 → 8.1 (+0%) | 6.3 → 6.3 (+1%) |
| get_hit | 5.9 → 5.2 (-13%) | 5.2 → 5.0 (-5%) | 4.9 → 4.8 (-3%) | 4.9 → 4.8 (-1%) | 3.3 → 3.2 (-2%) |
| get_miss | 4.8 → 4.5 (-6%) | 4.5 → 4.3 (-5%) | 4.3 → 4.3 (-2%) | 4.3 → 4.2 (-1%) | 2.8 → 2.8 (-0%) |
| get_batch | 8.2 → 7.7 (-7%) | 7.9 → 7.7 (-2%) | 7.7 → 7.6 (-1%) | 7.7 → 7.6 (-1%) | 4.2 → 4.2 (+0%) |
| update | 9.4 → 8.6 (-8%) | 8.8 → 8.4 (-5%) | 8.5 → 8.2 (-3%) | 8.4 → 8.4 (-0%) | 6.6 → 6.6 (+0%) |
| delete | 5.8 → 5.2 (-12%) | 5.5 → 4.9 (-10%) | 5.1 → 4.7 (-8%) | 4.9 → 4.8 (-1%) | 3.3 → 3.3 (-0%) |

**dense_rand: dTLB misses per operation (load + store)**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**dense_rand: Time per operation (ns/op)**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | 16.6 → 12.8 (-23%) | 17.0 → 12.6 (-26%) | 19.1 → 12.6 (-34%) | 16.6 → 12.7 (-23%) | 12.8 → 9.6 (-25%) |
| get_hit | 13.1 → 10.1 (-23%) | 13.0 → 9.9 (-24%) | 16.0 → 10.0 (-38%) | 13.1 → 9.9 (-24%) | 7.8 → 6.2 (-21%) |
| get_miss | 9.5 → 9.1 (-5%) | 9.6 → 8.9 (-7%) | 9.8 → 9.1 (-8%) | 9.5 → 9.0 (-5%) | 5.4 → 5.0 (-7%) |
| get_batch | 9.5 → 7.9 (-17%) | 9.5 → 7.7 (-19%) | 9.8 → 7.7 (-21%) | 9.5 → 7.8 (-18%) | 5.1 → 4.5 (-12%) |
| update | 17.7 → 15.6 (-12%) | 18.6 → 13.4 (-28%) | 21.3 → 13.5 (-37%) | 17.2 → 13.6 (-21%) | 13.0 → 9.9 (-24%) |
| delete | 14.0 → 11.8 (-16%) | 14.0 → 9.8 (-30%) | 16.7 → 9.8 (-41%) | 12.6 → 9.9 (-22%) | 7.9 → 5.7 (-29%) |

**rand: dTLB misses per operation (load + store)**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | - | - | - | - | - |
| get_hit | - | - | - | - | - |
| get_miss | - | - | - | - | - |
| get_batch | - | - | - | - | - |
| update | - | - | - | - | - |
| delete | - | - | - | - | - |

**rand: Time per operation (ns/op)**

| op | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| insert | 16.8 → 13.0 (-22%) | 17.7 → 12.6 (-29%) | 17.8 → 12.8 (-28%) | 16.8 → 12.7 (-24%) | 12.9 → 9.7 (-25%) |
| get_hit | 12.9 → 11.1 (-14%) | 14.0 → 9.8 (-30%) | 13.8 → 10.2 (-26%) | 12.7 → 10.0 (-21%) | 7.9 → 6.1 (-23%) |
| get_miss | 10.8 → 9.0 (-17%) | 11.0 → 8.8 (-20%) | 10.9 → 8.9 (-19%) | 10.8 → 8.8 (-19%) | 6.3 → 5.1 (-20%) |
| get_batch | 9.5 → 7.9 (-16%) | 9.5 → 7.8 (-18%) | 9.7 → 7.8 (-19%) | 9.5 → 7.7 (-19%) | 5.2 → 4.4 (-14%) |
| update | 18.3 → 14.7 (-20%) | 19.6 → 13.1 (-33%) | 20.3 → 14.0 (-31%) | 17.4 → 13.9 (-20%) | 13.1 → 10.0 (-24%) |
| delete | 13.6 → 10.8 (-21%) | 15.2 → 9.5 (-37%) | 16.2 → 10.5 (-35%) | 12.5 → 10.2 (-18%) | 7.9 → 5.8 (-27%) |

## Fastest variant per workload (1M keys, ns/op)

**base pages**

| op | seq | dense_rand | rand |
|---|---|---|---|
| insert | j=20 (6.3) | j=20 (12.8) | j=20 (12.9) |
| get_hit | j=20 (3.3) | j=20 (7.8) | j=20 (7.9) |
| get_miss | j=20 (2.8) | j=20 (5.4) | j=20 (6.3) |
| get_batch | j=20 (4.2) | j=20 (5.1) | j=20 (5.2) |
| update | j=20 (6.6) | j=20 (13.0) | j=20 (13.1) |
| delete | j=20 (3.3) | j=20 (7.9) | j=20 (7.9) |

**hugetlb pages**

| op | seq | dense_rand | rand |
|---|---|---|---|
| insert | j=20 (6.3) | j=20 (9.6) | j=20 (9.7) |
| get_hit | j=20 (3.2) | j=20 (6.2) | j=20 (6.1) |
| get_miss | j=20 (2.8) | j=20 (5.0) | j=20 (5.1) |
| get_batch | j=20 (4.2) | j=20 (4.5) | j=20 (4.4) |
| update | j=20 (6.6) | j=20 (9.9) | j=20 (10.0) |
| delete | j=20 (3.3) | j=20 (5.7) | j=20 (5.8) |

## Results by workload

Rows = key count, columns = variant. All values are per operation (medians). The CSV file has every metric, including cycles and page faults.

### base pages / seq / insert

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 10.3 | 9.7 | 9.3 | 9.9 | 8.2 |
| 10K | 10.3 | 10.0 | 8.8 | 10.0 | 7.3 |
| 100K | 9.0 | 8.3 | 8.2 | 8.1 | 6.1 |
| 500K | 9.1 | 8.3 | 8.1 | 8.1 | 6.3 |
| 1M | 9.0 | 8.3 | 8.2 | 8.1 | 6.3 |

### base pages / seq / get_hit

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.8 | 4.7 | 4.7 | 4.7 | 3.0 |
| 10K | 4.7 | 4.7 | 4.7 | 4.7 | 2.9 |
| 100K | 5.9 | 5.1 | 4.9 | 4.8 | 3.3 |
| 500K | 5.9 | 5.1 | 4.9 | 4.9 | 3.3 |
| 1M | 5.9 | 5.2 | 4.9 | 4.9 | 3.3 |

### base pages / seq / get_miss

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.0 | 4.0 | 4.0 | 4.0 | 2.2 |
| 10K | 4.0 | 4.0 | 4.0 | 3.9 | 2.2 |
| 100K | 5.2 | 4.5 | 4.3 | 4.2 | 2.8 |
| 500K | 6.5 | 6.5 | 5.7 | 5.8 | 3.7 |
| 1M | 4.8 | 4.5 | 4.3 | 4.3 | 2.8 |

### base pages / seq / get_batch

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 7.6 | 7.6 | 7.6 | 7.7 | 4.1 |
| 10K | 7.7 | 7.7 | 7.6 | 7.7 | 4.2 |
| 100K | 8.1 | 7.8 | 7.7 | 7.7 | 4.1 |
| 500K | 8.2 | 7.8 | 7.7 | 7.7 | 4.2 |
| 1M | 8.2 | 7.9 | 7.7 | 7.7 | 4.2 |

### base pages / seq / update

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 8.3 | 8.3 | 8.4 | 8.3 | 6.5 |
| 10K | 8.3 | 8.5 | 8.4 | 8.3 | 6.6 |
| 100K | 9.2 | 8.5 | 8.4 | 8.4 | 6.6 |
| 500K | 9.3 | 8.6 | 8.4 | 8.3 | 6.6 |
| 1M | 9.4 | 8.8 | 8.5 | 8.4 | 6.6 |

### base pages / seq / delete

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.7 | 5.0 | 4.7 | 4.8 | 3.0 |
| 10K | 4.6 | 4.8 | 4.7 | 4.6 | 2.9 |
| 100K | 5.9 | 5.1 | 4.8 | 4.9 | 3.4 |
| 500K | 5.8 | 5.1 | 4.9 | 4.8 | 3.3 |
| 1M | 5.8 | 5.5 | 5.1 | 4.9 | 3.3 |

### base pages / dense_rand / insert

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 12.4 | 11.9 | 11.9 | 12.0 | 9.1 |
| 10K | 14.2 | 16.2 | 13.1 | 15.0 | 10.2 |
| 100K | 13.3 | 13.2 | 13.1 | 13.1 | 10.1 |
| 500K | 15.8 | 15.8 | 15.8 | 15.6 | 12.3 |
| 1M | 16.6 | 17.0 | 19.1 | 16.6 | 12.8 |

### base pages / dense_rand / get_hit

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 5.4 | 5.0 | 5.0 | 5.0 | 3.0 |
| 10K | 5.7 | 5.6 | 5.4 | 5.4 | 3.1 |
| 100K | 10.2 | 10.1 | 10.2 | 10.2 | 6.2 |
| 500K | 12.0 | 12.0 | 12.0 | 12.0 | 7.5 |
| 1M | 13.1 | 13.0 | 16.0 | 13.1 | 7.8 |

### base pages / dense_rand / get_miss

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.5 | 4.6 | 4.5 | 4.6 | 2.4 |
| 10K | 6.1 | 6.1 | 6.1 | 6.1 | 3.7 |
| 100K | 10.7 | 10.8 | 10.7 | 10.8 | 6.5 |
| 500K | 18.3 | 22.3 | 22.1 | 19.7 | 8.5 |
| 1M | 9.5 | 9.6 | 9.8 | 9.5 | 5.4 |

### base pages / dense_rand / get_batch

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 8.1 | 7.5 | 7.6 | 7.6 | 4.1 |
| 10K | 8.4 | 8.1 | 7.6 | 7.7 | 4.2 |
| 100K | 8.5 | 8.3 | 7.9 | 7.9 | 4.2 |
| 500K | 9.4 | 9.7 | 9.5 | 9.4 | 4.9 |
| 1M | 9.5 | 9.5 | 9.8 | 9.5 | 5.1 |

### base pages / dense_rand / update

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 9.2 | 8.8 | 8.7 | 8.7 | 6.3 |
| 10K | 8.7 | 8.9 | 8.6 | 8.4 | 6.5 |
| 100K | 13.6 | 13.6 | 13.5 | 13.6 | 10.2 |
| 500K | 16.0 | 16.2 | 16.1 | 15.9 | 12.3 |
| 1M | 17.7 | 18.6 | 21.3 | 17.2 | 13.0 |

### base pages / dense_rand / delete

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 5.3 | 5.0 | 5.0 | 4.9 | 3.0 |
| 10K | 5.3 | 5.5 | 5.3 | 5.1 | 3.5 |
| 100K | 9.7 | 9.7 | 9.7 | 9.7 | 5.7 |
| 500K | 11.4 | 11.5 | 11.4 | 11.3 | 7.3 |
| 1M | 14.0 | 14.0 | 16.7 | 12.6 | 7.9 |

### base pages / rand / insert

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 25.3 | 28.3 | 34.3 | 35.4 | 18.3 |
| 10K | 22.7 | 26.8 | 25.6 | 21.4 | 16.7 |
| 100K | 16.3 | 16.3 | 16.2 | 16.2 | 12.8 |
| 500K | 16.2 | 16.2 | 16.1 | 16.1 | 12.6 |
| 1M | 16.8 | 17.7 | 17.8 | 16.8 | 12.9 |

### base pages / rand / get_hit

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 6.0 | 5.8 | 5.8 | 5.8 | 3.4 |
| 10K | 7.3 | 7.2 | 7.3 | 7.2 | 4.7 |
| 100K | 12.1 | 12.2 | 12.2 | 12.2 | 7.6 |
| 500K | 12.2 | 12.2 | 12.3 | 12.2 | 7.7 |
| 1M | 12.9 | 14.0 | 13.8 | 12.7 | 7.9 |

### base pages / rand / get_miss

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.5 | 4.6 | 4.6 | 4.5 | 2.5 |
| 10K | 6.1 | 6.2 | 6.2 | 6.1 | 3.8 |
| 100K | 11.2 | 10.8 | 11.4 | 10.8 | 6.3 |
| 500K | 21.6 | 20.7 | 19.3 | 16.1 | 7.8 |
| 1M | 10.8 | 11.0 | 10.9 | 10.8 | 6.3 |

### base pages / rand / get_batch

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 7.9 | 7.8 | 7.8 | 7.7 | 4.2 |
| 10K | 9.0 | 9.2 | 9.2 | 9.2 | 4.8 |
| 100K | 9.3 | 9.4 | 9.4 | 9.3 | 5.0 |
| 500K | 9.9 | 9.9 | 9.7 | 9.4 | 5.0 |
| 1M | 9.5 | 9.5 | 9.7 | 9.5 | 5.2 |

### base pages / rand / update

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 8.9 | 8.9 | 9.0 | 8.7 | 6.6 |
| 10K | 10.8 | 10.9 | 10.9 | 11.0 | 8.5 |
| 100K | 16.2 | 16.2 | 16.2 | 16.2 | 12.7 |
| 500K | 17.2 | 16.9 | 17.1 | 16.2 | 12.8 |
| 1M | 18.3 | 19.6 | 20.3 | 17.4 | 13.1 |

### base pages / rand / delete

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 5.6 | 5.8 | 5.7 | 5.5 | 4.1 |
| 10K | 7.6 | 7.7 | 7.6 | 7.7 | 5.8 |
| 100K | 11.5 | 11.5 | 11.5 | 11.5 | 7.5 |
| 500K | 11.8 | 11.8 | 11.8 | 11.6 | 7.5 |
| 1M | 13.6 | 15.2 | 16.2 | 12.5 | 7.9 |

### hugetlb pages / seq / insert

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 8.9 | 8.1 | 8.7 | 8.4 | 8.2 |
| 10K | 8.1 | 8.0 | 8.9 | 8.6 | 6.6 |
| 100K | 9.1 | 7.9 | 8.1 | 8.1 | 6.3 |
| 500K | 8.5 | 8.2 | 8.1 | 8.1 | 6.2 |
| 1M | 8.3 | 8.1 | 8.1 | 8.1 | 6.3 |

### hugetlb pages / seq / get_hit

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.8 | 4.7 | 4.7 | 4.7 | 3.0 |
| 10K | 5.1 | 4.9 | 4.7 | 4.6 | 2.9 |
| 100K | 5.2 | 4.9 | 4.9 | 4.8 | 3.2 |
| 500K | 5.2 | 4.9 | 4.9 | 4.8 | 3.3 |
| 1M | 5.2 | 5.0 | 4.8 | 4.8 | 3.2 |

### hugetlb pages / seq / get_miss

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.0 | 4.0 | 4.0 | 3.9 | 2.2 |
| 10K | 4.5 | 4.2 | 3.9 | 4.0 | 2.2 |
| 100K | 4.6 | 4.3 | 4.2 | 4.2 | 2.7 |
| 500K | 5.9 | 4.8 | 5.6 | 6.2 | 2.9 |
| 1M | 4.5 | 4.3 | 4.3 | 4.2 | 2.8 |

### hugetlb pages / seq / get_batch

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 7.7 | 7.6 | 7.6 | 7.6 | 4.2 |
| 10K | 7.6 | 7.7 | 7.6 | 7.6 | 4.1 |
| 100K | 7.7 | 7.6 | 7.6 | 7.7 | 4.1 |
| 500K | 7.7 | 7.7 | 7.7 | 7.7 | 4.1 |
| 1M | 7.7 | 7.7 | 7.6 | 7.6 | 4.2 |

### hugetlb pages / seq / update

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 8.1 | 8.2 | 8.3 | 8.2 | 6.5 |
| 10K | 8.5 | 8.2 | 8.3 | 8.2 | 6.4 |
| 100K | 9.5 | 8.1 | 8.2 | 8.3 | 6.6 |
| 500K | 8.8 | 8.4 | 8.4 | 8.3 | 6.6 |
| 1M | 8.6 | 8.4 | 8.2 | 8.4 | 6.6 |

### hugetlb pages / seq / delete

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 5.0 | 4.9 | 4.8 | 4.8 | 3.1 |
| 10K | 5.0 | 4.7 | 4.6 | 4.6 | 2.9 |
| 100K | 5.8 | 4.6 | 4.8 | 4.9 | 3.3 |
| 500K | 5.3 | 5.0 | 4.8 | 4.8 | 3.3 |
| 1M | 5.2 | 4.9 | 4.7 | 4.8 | 3.3 |

### hugetlb pages / dense_rand / insert

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 12.2 | 11.2 | 11.4 | 11.3 | 8.9 |
| 10K | 12.2 | 13.1 | 12.8 | 12.3 | 9.4 |
| 100K | 12.8 | 12.3 | 12.4 | 12.3 | 9.4 |
| 500K | 12.5 | 12.5 | 12.4 | 12.4 | 9.4 |
| 1M | 12.8 | 12.6 | 12.6 | 12.7 | 9.6 |

### hugetlb pages / dense_rand / get_hit

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 5.0 | 5.0 | 5.0 | 5.0 | 3.1 |
| 10K | 9.6 | 9.5 | 5.1 | 5.0 | 2.9 |
| 100K | 9.6 | 9.6 | 9.6 | 9.6 | 5.7 |
| 500K | 9.6 | 9.7 | 9.7 | 9.7 | 5.9 |
| 1M | 10.1 | 9.9 | 10.0 | 9.9 | 6.2 |

### hugetlb pages / dense_rand / get_miss

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.0 | 4.0 | 4.0 | 4.0 | 2.2 |
| 10K | 4.1 | 4.1 | 4.2 | 4.1 | 2.3 |
| 100K | 8.7 | 8.6 | 8.6 | 8.7 | 4.9 |
| 500K | 11.9 | 13.2 | 18.2 | 13.2 | 6.8 |
| 1M | 9.1 | 8.9 | 9.1 | 9.0 | 5.0 |

### hugetlb pages / dense_rand / get_batch

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 7.7 | 7.6 | 7.6 | 7.6 | 4.1 |
| 10K | 7.7 | 7.7 | 7.6 | 7.6 | 4.1 |
| 100K | 7.7 | 7.6 | 7.6 | 7.7 | 4.2 |
| 500K | 7.7 | 7.7 | 7.8 | 7.7 | 4.2 |
| 1M | 7.9 | 7.7 | 7.7 | 7.8 | 4.5 |

### hugetlb pages / dense_rand / update

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 8.3 | 9.0 | 8.9 | 8.9 | 6.6 |
| 10K | 12.7 | 12.8 | 8.8 | 8.8 | 6.7 |
| 100K | 13.2 | 12.7 | 12.8 | 13.0 | 9.5 |
| 500K | 13.0 | 13.0 | 13.1 | 12.9 | 9.6 |
| 1M | 15.6 | 13.4 | 13.5 | 13.6 | 9.9 |

### hugetlb pages / dense_rand / delete

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 5.5 | 5.2 | 4.9 | 4.9 | 3.1 |
| 10K | 9.0 | 8.9 | 4.8 | 4.8 | 2.9 |
| 100K | 9.4 | 8.9 | 9.1 | 9.1 | 5.3 |
| 500K | 9.2 | 9.2 | 9.3 | 9.2 | 5.4 |
| 1M | 11.8 | 9.8 | 9.8 | 9.9 | 5.7 |

### hugetlb pages / rand / insert

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 12.7 | 16.6 | 12.7 | 13.1 | 14.8 |
| 10K | 17.9 | 12.6 | 14.8 | 13.0 | 10.1 |
| 100K | 12.6 | 12.4 | 12.4 | 12.3 | 9.5 |
| 500K | 12.4 | 12.4 | 12.4 | 12.5 | 9.4 |
| 1M | 13.0 | 12.6 | 12.8 | 12.7 | 9.7 |

### hugetlb pages / rand / get_hit

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 5.1 | 5.0 | 5.1 | 5.1 | 3.0 |
| 10K | 5.1 | 5.0 | 5.1 | 5.1 | 3.0 |
| 100K | 9.7 | 9.6 | 9.6 | 9.7 | 5.8 |
| 500K | 9.7 | 9.7 | 9.7 | 9.7 | 5.9 |
| 1M | 11.1 | 9.8 | 10.2 | 10.0 | 6.1 |

### hugetlb pages / rand / get_miss

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 4.0 | 4.0 | 4.0 | 4.0 | 2.2 |
| 10K | 4.2 | 4.1 | 4.2 | 4.1 | 2.2 |
| 100K | 8.7 | 8.7 | 8.6 | 8.8 | 5.0 |
| 500K | 17.4 | 12.8 | 13.6 | 16.3 | 5.6 |
| 1M | 9.0 | 8.8 | 8.9 | 8.8 | 5.1 |

### hugetlb pages / rand / get_batch

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 7.6 | 7.7 | 7.6 | 7.6 | 4.1 |
| 10K | 7.6 | 7.7 | 7.7 | 7.6 | 4.1 |
| 100K | 7.7 | 7.7 | 7.7 | 7.7 | 4.2 |
| 500K | 7.8 | 7.7 | 7.7 | 8.0 | 4.2 |
| 1M | 7.9 | 7.8 | 7.8 | 7.7 | 4.4 |

### hugetlb pages / rand / update

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 8.6 | 8.3 | 8.6 | 8.6 | 6.2 |
| 10K | 8.3 | 8.3 | 8.3 | 8.4 | 6.2 |
| 100K | 12.9 | 12.8 | 12.8 | 12.9 | 9.6 |
| 500K | 13.0 | 12.9 | 12.9 | 13.1 | 9.6 |
| 1M | 14.7 | 13.1 | 14.0 | 13.9 | 10.0 |

### hugetlb pages / rand / delete

Time per operation (ns/op)

| keys | j=6 | j=8 | j=11 | j=15 | j=20 |
|---|---:|---:|---:|---:|---:|
| 1K | 5.0 | 5.0 | 5.0 | 5.0 | 3.3 |
| 10K | 4.7 | 4.8 | 4.8 | 4.8 | 3.0 |
| 100K | 9.1 | 9.1 | 9.0 | 9.1 | 5.4 |
| 500K | 9.2 | 9.1 | 9.1 | 9.2 | 5.4 |
| 1M | 10.8 | 9.5 | 10.5 | 10.2 | 5.8 |
