# Experiment 06: create / fill / clear / destroy cost

1000000 keys inserted in random order, 32 B inline values. RSS = VmRSS, hugetlb = HugetlbPages (from /proc/self/status; n/a elsewhere).

| pages | populate | create ms | RSS after create MiB | hugetlb after create MiB | fill ns/op | minor faults during fill | RSS after fill MiB | clear ms | destroy ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| base | no | 0.03 | 5.6 | 0.0 | 72.8 | 31250 | 66.6 | 4.79 | 2.78 |
| base | yes | 20.30 | 69.6 | 0.0 | 18.5 | 0 | 69.6 | 2.47 | 2.11 |
| hugetlb | no | 0.03 | 5.6 | 0.0 | 40.7 | 64 | 5.6 | 4.43 | 0.05 |
| hugetlb | yes | 2.59 | 5.6 | 64.0 | 12.6 | 0 | 5.6 | 2.45 | 0.03 |

Expected: populate moves the page-fault cost from the first fill into create. With hugetlb, a lazy (populate = no) fill faults about 32 times (one per 2 MiB page) instead of about 16,384 (one per 4 KiB page).
